import dotenv from 'dotenv';
dotenv.config();

export const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY; 